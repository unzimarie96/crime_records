<?php

	// Including Connection
	include 'dbconn.php';
    
    // Including Error Check file
	include 'error.php';

    // Check if the session are setted
    if (!empty($_SESSION['userid'])) {
        // Create a storage variable
        $id = $_SESSION['userid'];

        
        // Select data based on Identification
        $id_query = mysqli_query($conn,"SELECT * FROM accounts WHERE id = '$id'");
        // Assign data to an array
        $values = mysqli_fetch_assoc($id_query);

        // Create usage variables
        $icon = substr($values['names'], 0, 1);
        $full = $values['names'];

        // Count all tables records

        // Officers Count
        $off_query = mysqli_query($conn,"SELECT * FROM officers");
        $off_count = mysqli_num_rows($off_query);

        // Crimes Count
        $crime_query = mysqli_query($conn,"SELECT * FROM crimes");
        $crime_count = mysqli_num_rows($crime_query);

    }else{
        header("location: login.php?error-txt=3");
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Officers Panel | CRIME System</title>
	<link rel="stylesheet" type="text/css" href="assets/bootstrap/4.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="assets/style/style.css">
</head>
<body>
    <div class="header">
        <a href="#" class="logo">CRIMeSystem</a>
        <div class="header-right">
            <a href="index.php">Home</a>
            <a class="active" href="access-officers.php">Officers <span class="badge badge-light"><?php echo $off_count;?></span></a>
            <a href="access-crime.php">Crimes <span class="badge badge-primary"><?php echo $crime_count;?></span></a>
            <a href="access-reports.php">Reports</a>
            <a href="view-profile.php">
                <span class="short-letter"><?php echo $icon;?></span>
                <span class="full-name"><?php echo $full; ?></span>
            </a>
        </div>
    </div>
    <?php
    
        // Checking if act_id is not empty
        if (!empty($_GET['act_id'])) {
            // Create variables
            $act_id = $_GET['act_id'];

            if (!empty($_GET['action'])) {
                // Switch actions to be performed
                switch ($_GET['action']) {
                    case 'update':
    ?>
    <div class="card bg-dark">
		<div class="card-header">
			<h3>Create an account</h3>
		</div>
		<form method="POST" class="card-body">
			<div class="form-group">
				<label>Names:</label>
				<input type="text" name="names" class="form-control" maxlength="255" minlength="1" required>
			</div>
			<div class="form-group">
				<label>Username:</label>
				<input type="text" name="username" class="form-control" maxlength="255" minlength="1" required>
			</div>
			<div class="form-group">
				<label>Password:</label>
				<input type="password" name="password" class="form-control" maxlength="255" minlength="8" required>
			</div>
			<div class="form-group">
				<label>Date of birth:</label>
				<input type="date" name="birthday" class="form-control" required>
			</div>
			<button class="btn btn-primary form-control" type="submit" name="signup">Signup</button>
		</form>
		<div class="card-footer"></div>
    </div>
    <?php
                        break;

                    case 'delete':
                        // Delete an officer from table
                        $off_trash = mysqli_query($conn,"DELETE FROM officers WHERE id = '$act_id'");

                        // Check if the officer removed
                        if ($off_trash == TRUE) {
                            // Redirect to officer page with error n:8
                            header("location: access-officers.php?error-txt=8");
                        }else{
                             // Redirect to officer page with error n:7
                            header("location: access-officers.php?error-txt=7");
                        }

                        break;
                    
                    default:
                        
                        break;
                }
            }else{
                // Redirect to access officers with error n:6
                header("location: access-officers.php?error-txt=6");
            }
        }


    ?>
    <div class="tb-elements">
        <div class="container">
            <br><h2>Officers Data</h2>
            <p>All the information found in these table are not genuine so that they are used in system:</p><br>
            <div class="table-responsive-sm">          
                <table class="table table-hover table-bordered">
                    <thead>
                        <tr class="bg-dark text-white">
                            <th>#</th>
                            <th>Names</th>
                            <th>Gender</th>
                            <th>Email</th>
                            <th>Address</th>
                            <th>Birthday</th>
                            <th>Rank</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
    <?php
    
        // Selecting Officers data
        $off_data = mysqli_query($conn,"SELECT * FROM officers");

        // Checking rows found
        if (mysqli_num_rows($off_data) > 0) {
            while ($data = mysqli_fetch_assoc($off_data)) {
    ?>
                        <tr>
                            <td><?php echo $data['id']; ?></td>
                            <td><?php echo $data['names']; ?></td>
                            <td><?php echo $data['gender']; ?></td>
                            <td><?php echo $data['email']; ?></td>
                            <td><?php echo $data['address']; ?></td>
                            <td><?php echo $data['dob']; ?></td>
                            <td><?php echo $data['rank']; ?></td>
                            <td>
                                <a href="access-officers.php?action=update&act_id=<?php echo $data['id']; ?>" class="btn btn-success">Update</a>
                                <a href="access-officers.php?action=delete&act_id=<?php echo $data['id']; ?>" class="btn btn-danger">Delete</a>
                            </td>
                        </tr>
    <?php
            }
        }else{
    ?>
                        <tr>
                            <td colspan="7">No officers in system!</td>
                        </tr>
    <?php
        }
    
    ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="a-toast">
        Want to logout? <a href="logout.php">Click here</a>
    </div>
<script src="assets/scripts/main.js"></script>
<script src="assets/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</body>
</html>