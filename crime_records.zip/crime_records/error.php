<?php

// Checking if there is an error 
if (!empty($_GET['error-txt'])) {
    // Assign Variable
    $txt = $_GET['error-txt'];

    // Switch storen values
    switch ($txt) {
        case '1':
?>
<div class="alert alert-danger a-toast">
    <b>Message</b>
    <p>Failed to update status</p>
</div>
<?php
            break;
        case '2':
?>
<div class="alert alert-success a-toast">
    <b>Message</b>
    <p>You have logged out</p>
</div>
<?php
            break;
        case '3':
?>
<div class="alert alert-primary a-toast">
    <b>Message</b>
    <p>Login to continue access</p>
</div>
<?php
            break;
        case '4':
?>
<div class="alert alert-danger a-toast">
    <b>Message</b>
    <p>Failed to change satus of user</p>
</div>
<?php
            break;
        case '5':
    ?>
    <div class="alert alert-success b-toast">
        <b>Message</b>
        <p>You still logged in</p>
    </div>
    <?php
                break;
            case '6':
    ?>
    <div class="alert alert-danger b-toast">
        <b>Message</b>
        <p>No action choosed to perform</p>
    </div>
    <?php
                break;
            case '7':
    ?>
    <div class="alert alert-danger b-toast">
        <b>Message</b>
        <p>Failed to delete an officer</p>
    </div>
    <?php
                break;
            case '8':
    ?>
    <div class="alert alert-success b-toast">
        <b>Message</b>
        <p>An officer has been removed</p>
    </div>
    <?php
                break;
        
        default:
            echo "";
            break;
    }
}else{
    echo "";
}
        
?>